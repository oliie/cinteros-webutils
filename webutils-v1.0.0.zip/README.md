# Cinteros WebUtils
A package created to manage our bower-packages and dependencies in one place.

## Current Version
0.0.1

## Changelogs
### 0.0.1
- Added Select2

### 0.0.0
- Created package with:
    - Bootstrap-SASS
    - lodash
    - moment
    - ParsleyJS