function hello() {
    return "world";
}